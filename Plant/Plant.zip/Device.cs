﻿using DeviceInterface;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DeviceActor
{
    public class Device : Orleans.Grain, IDevice
    {
        private readonly ILogger logger;

        private string Status { get; set; }
        private List<string> alerts { get; set; }


        public Device(ILogger<Device> logger)
        {
            this.logger = logger;
        }

        Task<string> IDevice.SetStatus(string status)
        {
            Status = status;
            logger.LogInformation($"\n SetStatus message received: status = '{status}'");
            return Task.FromResult($"\n Client said: '{status}', so Actor says: OK, modified!");
        }
        Task<string> IDevice.AddAlert(string alertCode)
        {
            if (null == alerts)
                alerts = new List<string>();

            alerts.Add(alertCode);
            logger.LogInformation($"\n alertCode message received: added = '{alertCode}'");

            string currentAlerts = "";
            foreach (string alert in alerts)
                currentAlerts += alert + ",";

            return Task.FromResult($"\n Client said: '{alertCode}', so Actor says: OK, Added! - CurrentAlerts: '{currentAlerts}'");
        }

    }
}
