﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeviceInterface
{
    public interface IDevice : Orleans.IGrainWithIntegerKey
    {
        Task<string> SetStatus(string status);
        Task<string> AddAlert(string alertCode);

    }
}
